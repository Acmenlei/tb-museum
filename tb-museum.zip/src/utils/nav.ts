export const NavData = [
  {
    name: "首页",
    path: "/",
  },
  {
    name: "藏品",
    path: "/catalog",
  },
  {
    name: "搜索",
    path: "/search",
  },
  {
    name: "学术",
    path: "/academic",
  },
  {
    name: "资讯",
    path: "/information",
  },
  {
    name: "概览",
    path: "/profile",
  },
];
