<script setup lang="ts"></script>

<template>
  <div id="footer" class="mt-20">&copy; 版权信息待填写</div>
</template>

<style lang="scss" scoped>
#footer {
  max-width: 1000px;
  margin: 20px auto;
  padding: 0 20px;
  text-align: center;
}
</style>
