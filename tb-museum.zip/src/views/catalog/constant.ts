export const DynastyNames = ["全部", "唐", "宋", "元", "明", "清"];
export const StylesNames = ["全部", "青花", "红釉", "珐琅彩", "粉彩", "洋彩"];