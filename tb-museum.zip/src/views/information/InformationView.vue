<script setup lang='ts'>

</script>

<template>
资讯
</template>

<style lang='scss' scoped>

</style>