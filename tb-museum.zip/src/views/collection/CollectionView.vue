<script setup lang='ts'>

</script>

<template>
藏品页面。。。
</template>

<style lang='scss' scoped>

</style>