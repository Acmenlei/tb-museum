<script setup lang='ts'>

</script>

<template>
学术
</template>

<style lang='scss' scoped>

</style>