<script setup lang="ts"></script>

<template>
  <p class="mt-20">文物详情 > 瓷胎画珐琅红地花卉杯</p>
  <img src="@/assets/img/tb.jpg" alt="瓷胎画珐琅红地花卉杯" class="mt-10" />
  <h2>清 珐琅彩 瓷胎画珐琅红地花卉杯</h2>
</template>

<style lang="scss" scoped>
img {
  width: 1000px;
}
</style>
