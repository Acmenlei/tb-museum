<script setup lang="ts"></script>

<template>404 not found</template>

<style lang="scss" scoped></style>
